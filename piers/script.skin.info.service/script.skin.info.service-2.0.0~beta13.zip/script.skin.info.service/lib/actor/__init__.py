"""Actor image download functionality."""
