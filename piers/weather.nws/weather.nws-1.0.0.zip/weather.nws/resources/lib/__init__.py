"""NWS weather addon library."""
