"""Ratings updater - batch processing, item updates, and incremental sync."""
from __future__ import annotations

from typing import List, Dict, Optional, Set, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
import time
import xbmc
import xbmcgui

from lib.infrastructure import tasks as task_manager
from lib.kodi.client import (
    request, batch_request, get_library_items, _get_api_key, log,
    KODI_SET_DETAILS_METHODS, ADDON
)
from lib.data.api.tmdb import resolve_tmdb_id
from lib.data.api.mdblist import ApiMdblist as MDBListRatingsSource, BATCH_SIZE as MDBLIST_BATCH_SIZE
from lib.data.api.imdb import get_imdb_dataset
from lib.data.api.client import RateLimitHit, RetryableError
from lib.data.api.trakt import ApiTrakt
from lib.rating.merger import merge_ratings, prepare_kodi_ratings
from lib.data.api import tracker as usage_tracker
from lib.infrastructure.dialogs import show_ok, show_textviewer, show_notification, show_yesnocustom
from lib.data.database import workflow as db
from lib.rating.executor import RatingBatchExecutor, ItemState
from lib.rating.ids import get_imdb_id_from_tmdb, update_kodi_uniqueid

PROGRESS_SAVE_INTERVAL = 50

_tvshow_uniqueid_cache: Dict[int, Dict[str, str]] = {}


def _preserve_other_ratings(existing_ratings: Dict, kodi_ratings: Dict) -> None:
    """Copy non-imdb ratings from existing to kodi_ratings format."""
    for source_name, rating_data in existing_ratings.items():
        if source_name != "imdb" and isinstance(rating_data, dict):
            kodi_ratings[source_name] = {
                "rating": rating_data.get("rating", 0),
                "votes": int(rating_data.get("votes", 0)),
                "default": False
            }


def _build_external_ids(ids: Dict) -> Dict[str, str]:
    """Build external_ids dict from ids for database sync."""
    external_ids: Dict[str, str] = {}
    imdb_id = ids.get("imdb_episode") or ids.get("imdb")
    if imdb_id:
        external_ids["imdb"] = str(imdb_id)
    tmdb_id = ids.get("tmdb")
    if tmdb_id:
        external_ids["themoviedb"] = str(tmdb_id)
        external_ids["tmdb"] = str(tmdb_id)
    return external_ids


def _clear_tvshow_uniqueid_cache() -> None:
    """Clear the tvshow uniqueid cache. Call at start of batch operations."""
    _tvshow_uniqueid_cache.clear()


def _prefetch_tvshow_uniqueids() -> None:
    """Pre-fetch all TV show uniqueids in one request to populate cache."""
    response = request("VideoLibrary.GetTVShows", {"properties": ["uniqueid"]})
    if not response:
        return
    shows = response.get("result", {}).get("tvshows", [])
    for show in shows:
        tvshowid = show.get("tvshowid")
        uniqueid = show.get("uniqueid", {})
        if tvshowid:
            _tvshow_uniqueid_cache[tvshowid] = uniqueid
    log("Ratings", f"Pre-fetched uniqueids for {len(shows)} TV shows", xbmc.LOGDEBUG)


def _get_tvshow_uniqueid(tvshow_dbid: int) -> Dict[str, str]:
    """Fetch TV show uniqueid dict from Kodi library.

    Uses module-level cache to avoid redundant requests when processing
    multiple episodes from the same show.

    Args:
        tvshow_dbid: TV show database ID

    Returns:
        Dict of uniqueid values (tmdb, imdb, tvdb, etc.) or empty dict on failure
    """
    if tvshow_dbid in _tvshow_uniqueid_cache:
        return _tvshow_uniqueid_cache[tvshow_dbid]

    response = request("VideoLibrary.GetTVShowDetails", {
        "tvshowid": tvshow_dbid,
        "properties": ["uniqueid"]
    })
    if response and "tvshowdetails" in response.get("result", {}):
        uniqueid = response["result"]["tvshowdetails"].get("uniqueid", {})
        _tvshow_uniqueid_cache[tvshow_dbid] = uniqueid
        return uniqueid

    _tvshow_uniqueid_cache[tvshow_dbid] = {}
    return {}


def _prefetch_trakt_seasons(
    tvshow_dbid: int, episodes: List[Dict], sources: List
) -> None:
    """Prefetch Trakt episode data per-season for a show's episodes."""
    trakt_source = next((s for s in sources if isinstance(s, ApiTrakt)), None)
    if not trakt_source:
        return

    show_uniqueid = _get_tvshow_uniqueid(tvshow_dbid)
    show_imdb = show_uniqueid.get("imdb")
    if not show_imdb:
        return

    seasons: Set[int] = set()
    for ep in episodes:
        s = ep.get("season")
        if s is not None:
            seasons.add(s)
    for season in sorted(seasons):
        trakt_source.prefetch_season(show_imdb, season)


def _prefetch_trakt_seasons_batch(
    items: List[Dict], sources: List
) -> None:
    """Prefetch Trakt episode data for all show+season combos in a batch."""
    trakt_source = next((s for s in sources if isinstance(s, ApiTrakt)), None)
    if not trakt_source:
        return

    show_seasons: Dict[int, Set[int]] = {}
    for item in items:
        tvshow_dbid = item.get("tvshowid")
        season = item.get("season")
        if tvshow_dbid and season is not None:
            show_seasons.setdefault(tvshow_dbid, set()).add(season)

    for tvshow_dbid, seasons in show_seasons.items():
        show_uniqueid = _get_tvshow_uniqueid(tvshow_dbid)
        show_imdb = show_uniqueid.get("imdb")
        if not show_imdb:
            continue
        for season in sorted(seasons):
            trakt_source.prefetch_season(show_imdb, season)


def update_tvshow_episodes(tvshow_dbid: int, sources: List) -> int:
    """
    Update ratings for all episodes of a TV show.

    Args:
        tvshow_dbid: Database ID of the TV show
        sources: List of rating sources to use

    Returns:
        Number of episodes that were updated
    """
    response = request("VideoLibrary.GetEpisodes", {
        "tvshowid": tvshow_dbid,
        "properties": ["title", "season", "episode", "tvshowid", "uniqueid", "ratings"]
    })

    if not response or "episodes" not in response.get("result", {}):
        return 0

    episodes = response["result"]["episodes"]
    if not episodes:
        return 0

    log("Ratings", f"Updating ratings for {len(episodes)} episodes", xbmc.LOGINFO)

    _prefetch_trakt_seasons(tvshow_dbid, episodes, sources)

    updated_count = 0
    for episode in episodes:
        success, _ = update_single_item(episode, "episode", sources, force_refresh=False)
        if success:
            updated_count += 1

    return updated_count


_DRIP_DELAY = {
    "idle": {"movie": 100, "tvshow": 100, "episode": 100},
    "library": {"movie": 500, "tvshow": 1500, "episode": 1500},
}
_PLAYBACK_POLL_MS = 10000
_SYNC_FLUSH_SIZE = 50


def _get_kodi_state() -> str:
    if xbmc.getCondVisibility("Player.HasVideo"):
        return "playing"
    if xbmc.getCondVisibility("Window.IsVisible(10025)"):
        return "library"
    return "idle"


def update_changed_imdb_ratings(media_type: str = "", monitor: Optional[xbmc.Monitor] = None) -> Dict[str, int]:
    stats = {"updated": 0, "skipped": 0, "failed": 0}

    changed_items = db.get_imdb_changed_items(media_type if media_type else None)
    items_by_type: Dict[str, List[Dict]] = {}
    for item in changed_items:
        t = item["media_type"]
        if t not in items_by_type:
            items_by_type[t] = []
        items_by_type[t].append(item)

    new_batch_items, new_skipped = _collect_new_library_items(media_type, monitor)
    stats["skipped"] += new_skipped

    new_by_type: Dict[str, List[Dict]] = {}
    for mtype, batch_items in new_batch_items:
        new_by_type[mtype] = batch_items

    total_new = sum(len(bi) for bi in new_by_type.values())
    combined_total = len(changed_items) + total_new

    if combined_total == 0:
        return stats

    if changed_items:
        log("Ratings", f"Found {len(changed_items)} items with changed IMDb ratings", xbmc.LOGINFO)
    if total_new:
        log("Ratings", f"Found {total_new} new library items to sync", xbmc.LOGINFO)

    work_items: List[Tuple[str, Dict]] = []
    for mtype in ["movie", "tvshow", "episode"]:
        for item in items_by_type.get(mtype, []):
            work_items.append((mtype, item))
        for item in new_by_type.get(mtype, []):
            work_items.append((mtype, item))

    if not monitor:
        monitor = xbmc.Monitor()

    sync_batch: List[tuple] = []
    progress = xbmcgui.DialogProgressBG()
    progress.create(ADDON.getLocalizedString(32300))

    for idx, (item_media_type, item) in enumerate(work_items):
        if monitor.abortRequested():
            log("Ratings", "Abort requested, stopping incremental update", xbmc.LOGINFO)
            break

        pct = int((idx / combined_total) * 100)
        progress.update(pct, ADDON.getLocalizedString(32300),
                        ADDON.getLocalizedString(32307).format(idx + 1, combined_total))

        state = _get_kodi_state()
        if state == "playing":
            if sync_batch:
                db.update_synced_ratings_batch(sync_batch)
                sync_batch = []
            progress.close()
            while xbmc.getCondVisibility("Player.HasVideo"):
                if monitor.waitForAbort(_PLAYBACK_POLL_MS / 1000):
                    break
            if monitor.abortRequested():
                break
            progress.create(ADDON.getLocalizedString(32300))
            state = _get_kodi_state()

        set_method_info = KODI_SET_DETAILS_METHODS.get(item_media_type)
        if not set_method_info:
            stats["failed"] += 1
            continue

        if not item.get("imdb_id"):
            stats["skipped"] += 1
            continue

        set_method, set_id_key = set_method_info
        response = request(set_method, {
            set_id_key: item["dbid"],
            "ratings": {"imdb": {"rating": item["new_rating"], "votes": item["new_votes"], "default": True}}
        })

        if response is not None and "error" not in response:
            sync_batch.append((
                item_media_type, item["dbid"], 'imdb',
                item["imdb_id"], item["new_rating"], item["new_votes"]
            ))
            is_new = item.get('old_rating', 0.0) == 0.0 and item.get('old_votes', 0) == 0
            if is_new:
                log("Ratings", f"Added {item['imdb_id']}: imdb ({item['new_rating']:.1f})", xbmc.LOGDEBUG)
            else:
                log("Ratings", f"Updated {item['imdb_id']}: imdb ({item.get('old_rating', 0):.1f} -> {item['new_rating']:.1f})", xbmc.LOGDEBUG)
            stats["updated"] += 1
        elif response and "error" in response:
            db.clear_synced_ratings(item_media_type, item["dbid"])
            stats["failed"] += 1
        else:
            stats["failed"] += 1

        if len(sync_batch) >= _SYNC_FLUSH_SIZE:
            db.update_synced_ratings_batch(sync_batch)
            sync_batch = []

        delay_ms = _DRIP_DELAY.get(state, _DRIP_DELAY["idle"]).get(item_media_type, 100)
        xbmc.sleep(delay_ms)

    progress.close()

    if sync_batch:
        db.update_synced_ratings_batch(sync_batch)

    total = stats["updated"] + stats["skipped"] + stats["failed"]
    if total > 0:
        log("Ratings", f"Incremental update complete: {stats['updated']} updated, {stats['skipped']} skipped, {stats['failed']} failed", xbmc.LOGINFO)
    return stats


def _collect_new_library_items(
    media_type: str,
    monitor: Optional[xbmc.Monitor] = None,
) -> Tuple[List[Tuple[str, List[Dict]]], int]:
    """
    Collect new library items that need initial IMDb rating sync.

    Items whose Kodi rating already matches the dataset are batch-inserted
    into ratings_synced directly, avoiding unnecessary JSON-RPC SET calls.

    Args:
        media_type: Optional filter ("movie", "tvshow", "episode").
                   Empty string means all types.
        monitor: Optional xbmc.Monitor for abort checking.

    Returns:
        Tuple of (batch_items_by_type, skipped_count)
    """
    skipped = 0
    media_types = [media_type] if media_type else ["movie", "tvshow", "episode"]
    dataset = get_imdb_dataset()
    all_batch_items: List[Tuple[str, List[Dict]]] = []
    sync_batch_size = 5000

    for mtype in media_types:
        if monitor and monitor.abortRequested():
            break

        synced_dbids = db.get_synced_dbids(mtype)
        id_key = {"movie": "movieid", "tvshow": "tvshowid", "episode": "episodeid"}.get(mtype)
        if not id_key:
            continue

        props = ["uniqueid", "ratings", "title"]
        if mtype == "episode":
            props.extend(["season", "episode", "tvshowid"])

        items = get_library_items([mtype], properties=props)
        if not items:
            continue

        new_items = []
        imdb_ids_needed: List[str] = []
        for item in items:
            dbid = item.get(id_key)
            if not dbid or dbid in synced_dbids:
                continue
            imdb_id = _resolve_imdb_id(item, mtype, dataset)
            if not imdb_id:
                continue
            new_items.append(item)
            imdb_ids_needed.append(imdb_id)

        if not new_items:
            continue

        ratings_map = dataset.get_ratings_batch(imdb_ids_needed)

        batch_items: List[Dict] = []
        unchanged_syncs: List[tuple] = []
        type_skipped = 0
        for item, imdb_id in zip(new_items, imdb_ids_needed):
            rating_data = ratings_map.get(imdb_id)
            if not rating_data:
                skipped += 1
                type_skipped += 1
                continue

            existing_imdb = item.get("ratings", {}).get("imdb", {})
            existing_rating = existing_imdb.get("rating") if existing_imdb else None

            if existing_rating is not None and abs(existing_rating - rating_data["rating"]) <= 0.01:
                unchanged_syncs.append((mtype, item[id_key], 'imdb', imdb_id, rating_data["rating"], rating_data["votes"]))

                if len(unchanged_syncs) >= sync_batch_size:
                    db.update_synced_ratings_batch(unchanged_syncs)
                    unchanged_syncs = []
                continue

            batch_items.append({
                "dbid": item[id_key],
                "imdb_id": imdb_id,
                "new_rating": rating_data["rating"],
                "new_votes": rating_data["votes"],
                "old_rating": 0.0,
                "old_votes": 0,
            })

        if unchanged_syncs:
            db.update_synced_ratings_batch(unchanged_syncs)

        total_synced = len(new_items) - len(batch_items) - type_skipped
        if total_synced > 0:
            log("Ratings", f"Recorded {total_synced} already-synced {mtype} items", xbmc.LOGINFO)

        if batch_items:
            all_batch_items.append((mtype, batch_items))

    return all_batch_items, skipped


def _run_imdb_batch(
    media_type: str,
    items: List[Dict],
    progress: xbmcgui.DialogProgress | xbmcgui.DialogProgressBG,
    results: Dict,
    ctx: task_manager.TaskContext,
    monitor: xbmc.Monitor,
    dataset_date: str,
    processed_ids: Set[int],
) -> None:
    """Run IMDb dataset batch update. Mutates results and processed_ids in place."""

    def _should_abort() -> bool:
        return ctx.abort_flag.is_requested() or monitor.abortRequested()

    def _update_progress() -> None:
        current_count = len(processed_ids)
        percent = int((current_count / len(items)) * 100)
        if isinstance(progress, xbmcgui.DialogProgressBG):
            progress.update(percent, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32308).format(current_count, len(items)))
        elif isinstance(progress, xbmcgui.DialogProgress):
            progress.update(percent, ADDON.getLocalizedString(32309).format(current_count, len(items)))

    log("Ratings", f"Using BATCHED IMDb update for {len(items)} {media_type} items", xbmc.LOGINFO)
    batch_items_prepared = 0
    batch_items_skipped = 0
    id_key = "movieid" if media_type == "movie" else "tvshowid" if media_type == "tvshow" else "episodeid"
    set_method_info = KODI_SET_DETAILS_METHODS.get(media_type)
    if not set_method_info:
        log("Ratings", f"Unknown media type for SET: {media_type}", xbmc.LOGERROR)
        return

    set_method, set_id_key = set_method_info
    items_since_save = 0
    dataset = get_imdb_dataset()

    batch_start = 0
    while batch_start < len(items):
        if _should_abort():
            results["cancelled"] = True
            break

        if isinstance(progress, xbmcgui.DialogProgress) and progress.iscanceled():
            results["cancelled"] = True
            break

        batch_end = min(batch_start + 1000, len(items))
        batch = items[batch_start:batch_end]

        set_calls = []
        items_to_update = []
        unchanged_syncs: List[tuple] = []

        pending_items = []
        for item in batch:
            dbid = item.get(id_key)
            if dbid and dbid in processed_ids:
                continue
            imdb_id = _resolve_imdb_id(item, media_type, dataset)
            pending_items.append((item, imdb_id))

        all_imdb_ids = [iid for _, iid in pending_items if iid]
        batch_ratings = dataset.get_ratings_batch(all_imdb_ids) if all_imdb_ids else {}

        for item, resolved_imdb_id in pending_items:
            if _should_abort():
                log("Ratings", "Abort requested during item preparation", xbmc.LOGINFO)
                results["cancelled"] = True
                break

            dbid = item.get(id_key)

            prepared = _prepare_imdb_update(item, media_type, dataset, ratings_map=batch_ratings, resolved_imdb_id=resolved_imdb_id)
            if prepared is None:
                results["skipped"] += 1
                batch_items_skipped += 1
                if dbid:
                    processed_ids.add(dbid)
                continue

            dbid, kodi_ratings, imdb_id, new_rating, new_votes, title, year, is_add = prepared

            if kodi_ratings is None:
                unchanged_syncs.append((media_type, dbid, 'imdb', imdb_id, new_rating, new_votes))
                processed_ids.add(dbid)
                items_since_save += 1
                continue

            batch_items_prepared += 1
            set_calls.append({
                "method": set_method,
                "params": {set_id_key: dbid, "ratings": kodi_ratings}
            })
            items_to_update.append({
                "dbid": dbid,
                "imdb_id": imdb_id,
                "new_rating": new_rating,
                "new_votes": new_votes,
                "title": title,
                "year": year,
                "is_add": is_add
            })

        if results.get("cancelled"):
            break

        if set_calls:
            _update_progress()
            set_responses = batch_request(set_calls)

            if _should_abort():
                log("Ratings", "Abort requested after batch_request", xbmc.LOGINFO)
                results["cancelled"] = True
                break

            sync_batch: List[tuple] = []
            for i, update_info in enumerate(items_to_update):
                if _should_abort():
                    log("Ratings", "Abort requested during DB update loop", xbmc.LOGINFO)
                    results["cancelled"] = True
                    break

                response = set_responses[i] if i < len(set_responses) else None
                dbid = update_info["dbid"]

                if response is not None and "error" not in response:
                    sync_batch.append((
                        media_type, dbid, 'imdb',
                        update_info["imdb_id"], update_info["new_rating"], update_info["new_votes"]
                    ))
                    action = "Added" if update_info["is_add"] else "Updated"
                    log("Ratings", f"{action} {update_info['title']}: imdb ({update_info['new_rating']:.1f})", xbmc.LOGDEBUG)
                    results["updated"] += 1
                    if update_info["is_add"]:
                        results["total_ratings_added"] += 1
                    else:
                        results["total_ratings_updated"] += 1
                else:
                    results["failed"] += 1

                processed_ids.add(dbid)
                items_since_save += 1

            if sync_batch:
                db.update_synced_ratings_batch(sync_batch)

            if results.get("cancelled"):
                break

        if unchanged_syncs:
            db.update_synced_ratings_batch(unchanged_syncs)

        ctx.mark_progress()
        _update_progress()

        if items_since_save >= PROGRESS_SAVE_INTERVAL:
            db.save_imdb_update_progress(media_type, dataset_date, processed_ids, len(items))
            items_since_save = 0

        batch_start = batch_end

    log("Ratings", f"BATCHED complete: {batch_items_prepared} to update, {batch_items_skipped} skipped", xbmc.LOGINFO)

    if not results.get("cancelled"):
        db.clear_imdb_update_progress(media_type)
    elif dataset_date:
        db.save_imdb_update_progress(media_type, dataset_date, processed_ids, len(items))


def _run_multi_source_batch(
    media_type: str,
    items: List[Dict],
    sources: List,
    progress: xbmcgui.DialogProgress | xbmcgui.DialogProgressBG,
    results: Dict,
    retry_queue: List[Dict],
    ctx: task_manager.TaskContext,
    mdblist_fetcher: Optional[MdblistBatchFetcher],
) -> None:
    """Run multi-source batch update using RatingBatchExecutor. Mutates results and retry_queue in place."""

    def _collect_result(item: Dict, success: Optional[bool], item_stats: Optional[Dict]) -> None:
        if success:
            results["updated"] += 1
        elif success is None:
            results["skipped"] += 1
        else:
            results["failed"] += 1

        if not item_stats:
            return

        results["total_ratings_added"] += item_stats.get("ratings_added", 0)
        results["total_ratings_updated"] += item_stats.get("ratings_updated", 0)
        if item_stats.get("imdb_id_added"):
            results["imdb_ids_added"] += 1
        if item_stats.get("pending_correction"):
            results["pending_corrections"].append(item_stats["pending_correction"])

        for source_name in item_stats.get("sources_used", []):
            if source_name not in results["source_stats"]:
                results["source_stats"][source_name] = {"fetched": 0, "failed": 0}
            results["source_stats"][source_name]["fetched"] += 1

        if item_stats.get("ratings_added", 0) > 0 or item_stats.get("ratings_updated", 0) > 0:
            results["item_details"].append(item_stats)
            if len(results["item_details"]) > 20:
                results["item_details"].pop(0)

        retryable = item_stats.get("retryable_failures", [])
        if retryable:
            retry_queue.append({
                "item": item,
                "title": item_stats.get("title", "Unknown"),
                "year": item_stats.get("year", ""),
                "failures": retryable,
            })

    def _try_finalize(executor: RatingBatchExecutor, check_dbid: int, finalized_count: int) -> int:
        check_state = executor.get_item_state(check_dbid)
        if not check_state:
            return finalized_count

        all_sources_done = len(check_state.completed_sources) >= len(sources)
        timed_out = executor.check_item_timeout(check_dbid)

        if not all_sources_done and not timed_out:
            return finalized_count

        if timed_out and not all_sources_done:
            executor.timeout_pending_sources(check_dbid)

        success, item_stats = _finalize_item_ratings(check_state, media_type)
        executor.mark_item_finalized(check_dbid)
        _collect_result(check_state.item, success, item_stats)
        ctx.mark_progress()
        return finalized_count + 1

    with RatingBatchExecutor(sources, ctx.abort_flag) as executor:
        items_finalized = 0

        for i, item in enumerate(items):
            if executor.is_cancelled():
                results["cancelled"] = True
                break

            if isinstance(progress, xbmcgui.DialogProgress) and progress.iscanceled():
                results["cancelled"] = True
                break

            if mdblist_fetcher:
                mdblist_fetcher.fetch_batch_for_index(i, progress)

            prepared = _prepare_item_for_batch(item, media_type)
            dbid, title, year, ids, existing_ratings, initial_ratings, initial_sources = prepared

            if dbid is None or title is None or ids is None or existing_ratings is None:
                results["skipped"] += 1
                continue

            executor.submit_item(
                item=item, dbid=dbid, title=title, year=year or "",
                media_type=media_type, ids=ids, existing_ratings=existing_ratings,
            )

            state = executor.get_item_state(dbid)
            if state and initial_ratings and initial_sources:
                state.ratings.extend(initial_ratings)
                state.sources_used.extend(initial_sources)

            percent = int((i / len(items)) * 100)
            if isinstance(progress, xbmcgui.DialogProgressBG):
                progress.update(percent, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32306).format(i+1, len(items), title))
            elif isinstance(progress, xbmcgui.DialogProgress):
                progress.update(percent, f"{ADDON.getLocalizedString(32307).format(i+1, len(items))}\n{title}")

            collected = executor.collect_results(timeout=0.1)
            for result_dbid, source_name, result in collected:
                executor.process_result(result_dbid, source_name, result)

            for check_dbid in executor.get_unfinalized_items():
                items_finalized = _try_finalize(executor, check_dbid, items_finalized)

        while executor.get_unfinalized_items():
            if executor.is_cancelled():
                results["cancelled"] = True
                break

            if isinstance(progress, xbmcgui.DialogProgress) and progress.iscanceled():
                results["cancelled"] = True
                break

            collected = executor.collect_results(timeout=1.0)
            for result_dbid, source_name, result in collected:
                executor.process_result(result_dbid, source_name, result)

            for check_dbid in executor.get_unfinalized_items():
                items_finalized = _try_finalize(executor, check_dbid, items_finalized)

                percent = int((items_finalized / len(items)) * 100)
                if isinstance(progress, xbmcgui.DialogProgressBG):
                    progress.update(percent, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32308).format(items_finalized, len(items)))
                elif isinstance(progress, xbmcgui.DialogProgress):
                    progress.update(percent, ADDON.getLocalizedString(32309).format(items_finalized, len(items)))


def update_library_ratings(
    media_type: str,
    sources: List,
    use_background: bool = False,
    source_mode: str = "multi_source"
) -> Dict[str, int]:
    """Update ratings for all items of a media type."""
    start_time = time.time()
    usage_tracker.reset_session_skip()

    if media_type == "episode":
        _clear_tvshow_uniqueid_cache()
        properties = ["title", "season", "episode", "tvshowid", "uniqueid", "ratings"]
    else:
        properties = ["title", "year", "uniqueid", "ratings"]

    progress: xbmcgui.DialogProgress | xbmcgui.DialogProgressBG
    if use_background:
        progress = xbmcgui.DialogProgressBG()
        progress.create(ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32303).format(media_type))
    else:
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32303).format(media_type))

    items = get_library_items([media_type], properties=properties)
    if not items:
        if progress:
            progress.close()
        show_notification(
            ADDON.getLocalizedString(32300),
            ADDON.getLocalizedString(32413).format(media_type),
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        return {"updated": 0, "failed": 0, "skipped": 0}

    if isinstance(progress, xbmcgui.DialogProgressBG):
        progress.update(0, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32304).format(len(items), media_type))
    elif isinstance(progress, xbmcgui.DialogProgress):
        progress.update(0, ADDON.getLocalizedString(32304).format(len(items), media_type))

    results: Dict = {
        "updated": 0, "failed": 0, "skipped": 0,
        "total_items": len(items), "source_stats": {}, "item_details": [],
        "total_ratings_added": 0, "total_ratings_updated": 0,
        "imdb_ids_added": 0, "imdb_ids_corrected": 0,
        "pending_corrections": [], "source_mode": source_mode,
    }

    retry_queue: List[Dict] = []
    dataset_date: str = ""
    processed_ids: Set[int] = set()

    if source_mode == "imdb":
        dataset = get_imdb_dataset()
        if not dataset.is_dataset_available():
            if isinstance(progress, xbmcgui.DialogProgressBG):
                progress.update(0, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32305))
            elif isinstance(progress, xbmcgui.DialogProgress):
                progress.update(0, ADDON.getLocalizedString(32305))
            dataset.force_download()

        stats = dataset.get_stats()
        dataset_date = str(stats.get("last_modified") or "")

        saved_progress = db.get_imdb_update_progress(media_type)
        if saved_progress:
            if saved_progress["dataset_date"] == dataset_date:
                processed_ids = saved_progress["processed_ids"]
                log("Ratings", f"Resuming IMDb update for {media_type}: {len(processed_ids)}/{len(items)} already processed")
            else:
                db.clear_imdb_update_progress(media_type)
                log("Ratings", f"New IMDb dataset detected, starting fresh for {media_type}")

    mdblist_fetcher: MdblistBatchFetcher | None = None
    if source_mode == "multi_source" and media_type in ("movie", "tvshow"):
        mdblist_fetcher = MdblistBatchFetcher(items, media_type)

    if media_type == "episode":
        _ensure_episode_dataset(progress)
        _prefetch_tvshow_uniqueids()
        if source_mode == "multi_source":
            _prefetch_trakt_seasons_batch(items, sources)

    monitor = xbmc.Monitor()

    with task_manager.TaskContext("Update Library Ratings") as ctx:
        if source_mode == "imdb":
            _run_imdb_batch(media_type, items, progress, results, ctx, monitor, dataset_date, processed_ids)
        else:
            _run_multi_source_batch(media_type, items, sources, progress, results, retry_queue, ctx, mdblist_fetcher)

    if progress:
        progress.close()

    if retry_queue and not use_background and not results.get("cancelled"):
        retry_count = _prompt_and_process_retries(
            retry_queue, media_type, sources, source_mode
        )
        if retry_count > 0:
            results["retried"] = retry_count

    elapsed_time = time.time() - start_time
    results["elapsed_time"] = elapsed_time

    pending = results.get("pending_corrections", [])
    if pending and not use_background:
        results["imdb_ids_corrected"] = _prompt_imdb_corrections(pending)
    elif pending:
        log("Ratings", f"{len(pending)} IMDb ID redirects found but not corrected (background mode)", xbmc.LOGINFO)

    results.pop("pending_corrections", None)

    db.save_operation_stats('ratings_update', results, scope=media_type)

    if not use_background:
        cancelled_text = " (Cancelled)" if results.get("cancelled") else ""
        imdb_ids_text = f"\nIMDb IDs added: {results['imdb_ids_added']}" if results["imdb_ids_added"] > 0 else ""
        imdb_ids_corrected_text = f"\nIMDb IDs corrected: {results['imdb_ids_corrected']}" if results["imdb_ids_corrected"] > 0 else ""
        message = (
            f"Updated: {results['updated']}\n"
            f"Failed: {results['failed']}\n"
            f"Skipped: {results['skipped']}{cancelled_text}{imdb_ids_text}{imdb_ids_corrected_text}"
        )
        show_ok(ADDON.getLocalizedString(32317), message)

    xbmc.executebuiltin("Container.Refresh")

    return results


class MdblistBatchFetcher:
    """
    Manages just-in-time batch fetching of MDBList data.

    Fetches 200 items at a time, triggered when main loop reaches batch boundaries.
    Data is stored in SQLite cache for item-by-item retrieval.
    """

    def __init__(self, items: List[Dict], media_type: str):
        self.media_type = media_type
        self.mdblist = MDBListRatingsSource() if _get_api_key("mdblist_api_key") else None
        self.daily_limit_reached = False

        self.tmdb_ids: list[str] = []
        for item in items:
            uniqueid = item.get("uniqueid", {})
            raw_tmdb = uniqueid.get("tmdb")
            imdb_id = uniqueid.get("imdb")
            resolved = resolve_tmdb_id(str(raw_tmdb) if raw_tmdb else None, imdb_id, media_type)
            self.tmdb_ids.append(resolved or "")

        self.total_items = len(self.tmdb_ids)
        self.batches_fetched = 0

    def fetch_batch_for_index(
        self,
        index: int,
        progress: xbmcgui.DialogProgress | xbmcgui.DialogProgressBG | None = None
    ) -> None:
        """
        Fetch MDBList batch if needed for the given item index.

        Called at the start of processing each item. Only fetches when:
        - Item is at a batch boundary (0, 200, 400, etc.)
        - MDBList is configured and not rate limited
        - Media type supports MDBList (not episodes)

        Args:
            index: Current item index in the processing loop
            progress: Optional progress dialog to update
        """
        if not self.mdblist or self.daily_limit_reached:
            return

        if self.media_type == "episode":
            return

        if index % MDBLIST_BATCH_SIZE != 0:
            return

        batch_start = index
        batch_end = min(index + MDBLIST_BATCH_SIZE, self.total_items)

        batch_ids = [
            {"id": tmdb_id}
            for tmdb_id in self.tmdb_ids[batch_start:batch_end]
            if tmdb_id
        ]

        if not batch_ids:
            return

        batch_num = (index // MDBLIST_BATCH_SIZE) + 1
        total_batches = (self.total_items + MDBLIST_BATCH_SIZE - 1) // MDBLIST_BATCH_SIZE

        log("Ratings", f"Fetching MDBList batch {batch_num}/{total_batches} ({len(batch_ids)} items)", xbmc.LOGDEBUG)

        if progress:
            if isinstance(progress, xbmcgui.DialogProgressBG):
                progress.update(
                    int((index / self.total_items) * 100),
                    ADDON.getLocalizedString(32300),
                    ADDON.getLocalizedString(32414).format(batch_num, total_batches)
                )
            elif isinstance(progress, xbmcgui.DialogProgress):
                progress.update(
                    int((index / self.total_items) * 100),
                    ADDON.getLocalizedString(32414).format(batch_num, total_batches)
                )

        try:
            self.mdblist.fetch_batch(self.media_type, batch_ids, provider="tmdb")
            self.batches_fetched += 1
        except RateLimitHit:
            log("Ratings", "MDBList daily limit reached", xbmc.LOGWARNING)
            self.daily_limit_reached = True


def _prompt_and_process_retries(
    retry_queue: List[Dict],
    media_type: str,
    sources: List,
    source_mode: str
) -> int:
    """
    Show retry dialog and process items with transient failures.

    Args:
        retry_queue: List of items with retryable failures
        media_type: Type of media being processed
        sources: List of rating sources
        source_mode: Source mode identifier

    Returns:
        Number of items successfully retried
    """
    count = len(retry_queue)

    failure_summary: Dict[str, int] = {}
    for entry in retry_queue:
        for failure in entry.get("failures", []):
            source = failure.get("source", "unknown")
            failure_summary[source] = failure_summary.get(source, 0) + 1

    summary_parts = [f"{source}: {cnt}" for source, cnt in sorted(failure_summary.items())]
    summary_text = ", ".join(summary_parts)

    message = (
        f"{ADDON.getLocalizedString(32416).format(count)}\n"
        f"({summary_text})\n\n"
        f"{ADDON.getLocalizedString(32417)}"
    )

    while True:
        result = show_yesnocustom(
            ADDON.getLocalizedString(32415),
            message,
            customlabel=ADDON.getLocalizedString(32427),
            nolabel=ADDON.getLocalizedString(32128),
            yeslabel=ADDON.getLocalizedString(32429)
        )

        if result == 2:
            lines = [f"[B]{ADDON.getLocalizedString(32419)}[/B]", ""]
            for entry in retry_queue:
                title = entry.get("title", "Unknown")
                year = entry.get("year", "")
                year_str = f" ({year})" if year else ""
                lines.append(f"{title}{year_str}")

                for failure in entry.get("failures", []):
                    source = failure.get("source", "unknown")
                    reason = failure.get("reason", "unknown error")
                    lines.append(f"  {source}: {reason}")
                lines.append("")

            show_textviewer(ADDON.getLocalizedString(32418), "\n".join(lines))

        elif result == 1:
            return _process_retry_queue(retry_queue, media_type, sources, source_mode)

        else:
            log("Ratings", f"User skipped retry of {count} item{'s' if count > 1 else ''}", xbmc.LOGINFO)
            return 0


def _process_retry_queue(
    retry_queue: List[Dict],
    media_type: str,
    sources: List,
    source_mode: str
) -> int:
    """
    Process retry queue items.

    Args:
        retry_queue: List of items to retry
        media_type: Type of media
        sources: List of rating sources
        source_mode: Source mode identifier

    Returns:
        Number of items successfully updated on retry
    """
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32310))

    success_count = 0
    total = len(retry_queue)

    for i, entry in enumerate(retry_queue):
        if progress.iscanceled():
            break

        item = entry["item"]
        title = entry.get("title", "Unknown")

        percent = int((i / total) * 100)
        progress.update(percent, f"{ADDON.getLocalizedString(32311).format(i+1, total)}\n{title}")

        if source_mode == "imdb":
            success, _ = _update_single_item_imdb(item, media_type)
        else:
            success, _ = update_single_item(item, media_type, sources)

        if success:
            success_count += 1
            log("Ratings", f"Retry succeeded: {title}", xbmc.LOGDEBUG)
        else:
            log("Ratings", f"Retry failed: {title}", xbmc.LOGDEBUG)

    progress.close()

    if success_count > 0:
        show_notification(
            ADDON.getLocalizedString(32300),
            ADDON.getLocalizedString(32420).format(success_count, total),
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

    return success_count


def _ensure_episode_dataset(
    progress: xbmcgui.DialogProgress | xbmcgui.DialogProgressBG | None = None
) -> None:
    """
    Ensure episode IMDb ID dataset is up to date.

    Silently refreshes the dataset if library episode count changed
    or IMDb published an update. Does nothing if already current.
    """
    library_ep_count_str = xbmc.getInfoLabel('Window(Home).Property(Episodes.Count)')
    try:
        library_ep_count = int(library_ep_count_str) if library_ep_count_str else 0
    except ValueError:
        library_ep_count = 0

    if library_ep_count == 0:
        return

    dataset = get_imdb_dataset()

    if not dataset.needs_episode_refresh(library_ep_count):
        return

    shows = get_library_items(["tvshow"], properties=["uniqueid"])
    user_show_ids: set[str] = set()
    for show in shows:
        imdb_id = show.get("uniqueid", {}).get("imdb")
        if imdb_id:
            user_show_ids.add(imdb_id)

    if not user_show_ids:
        log("Ratings", "No TV shows with IMDb IDs, skipping episode dataset refresh")
        return

    if progress:
        if isinstance(progress, xbmcgui.DialogProgressBG):
            progress.update(0, ADDON.getLocalizedString(32300), ADDON.getLocalizedString(32312))
        elif isinstance(progress, xbmcgui.DialogProgress):
            progress.update(0, ADDON.getLocalizedString(32312))

    def progress_callback(status: str) -> None:
        if progress:
            if isinstance(progress, xbmcgui.DialogProgressBG):
                progress.update(0, ADDON.getLocalizedString(32300), status)
            elif isinstance(progress, xbmcgui.DialogProgress):
                progress.update(0, status)

    dataset.refresh_episode_dataset(user_show_ids, library_ep_count, progress_callback)


def _prompt_imdb_corrections(pending: List[Dict]) -> int:
    """
    Prompt user to correct outdated IMDb IDs.

    Shows a 3-button dialog: Show (view list), Yes (apply all), No (skip)

    Args:
        pending: List of pending correction dicts

    Returns:
        Number of corrections applied
    """
    count = len(pending)
    message = f"{ADDON.getLocalizedString(32422).format(count)}\n\n{ADDON.getLocalizedString(32423)}"

    while True:
        result = show_yesnocustom(
            ADDON.getLocalizedString(32421),
            message,
            customlabel=ADDON.getLocalizedString(32427),
            nolabel=xbmc.getLocalizedString(106),
            yeslabel=xbmc.getLocalizedString(107)
        )

        if result == 2:
            lines = [f"[B]{ADDON.getLocalizedString(32421)}[/B]", ""]
            for item in pending:
                title = item.get("title", "Unknown")
                year = item.get("year", "")
                year_str = f" ({year})" if year else ""
                old_id = item.get("old_id", "")
                new_id = item.get("new_id", "")
                lines.append(f"{title}{year_str}")
                lines.append(f"  {old_id} -> {new_id}")
                lines.append("")

            show_textviewer(ADDON.getLocalizedString(32421), "\n".join(lines))

        elif result == 1:
            corrected = 0
            for item in pending:
                success = update_kodi_uniqueid(
                    item["media_type"],
                    item["dbid"],
                    item["uniqueid"],
                    item["new_id"]
                )
                if success:
                    corrected += 1
                    log("Ratings", f"Corrected IMDb ID: {item['old_id']} -> {item['new_id']} for {item['title']}", xbmc.LOGINFO)

            return corrected

        else:
            log("Ratings", f"User skipped {count} IMDb ID correction{'s' if count > 1 else ''}", xbmc.LOGINFO)
            return 0


def _resolve_imdb_id(item: Dict, media_type: str, dataset) -> Optional[str]:
    uniqueid = item.get("uniqueid", {})

    if media_type == "episode":
        imdb_id = uniqueid.get("imdb")
        if imdb_id:
            return imdb_id
        tvshow_dbid = item.get("tvshowid")
        if tvshow_dbid:
            tvshow_uniqueid = _get_tvshow_uniqueid(tvshow_dbid)
            if tvshow_uniqueid:
                show_imdb = tvshow_uniqueid.get("imdb")
                season_num = item.get("season")
                episode_num = item.get("episode")
                if show_imdb and season_num is not None and episode_num is not None:
                    return dataset.get_episode_imdb_id(show_imdb, season_num, episode_num)
        return None

    return uniqueid.get("imdb") or None


def _prepare_imdb_update(
    item: Dict,
    media_type: str,
    dataset,
    db_cursor=None,
    ratings_map: Optional[Dict[str, Dict]] = None,
    resolved_imdb_id: Optional[str] = None
) -> Optional[Tuple[int, Optional[Dict], str, float, int, str, str, bool]]:
    dbid = item.get("movieid") or item.get("episodeid") or item.get("tvshowid")
    if not dbid:
        return None

    title = item.get("title", "Unknown")
    year = item.get("year", "")
    existing_ratings = item.get("ratings", {})

    imdb_id = resolved_imdb_id or _resolve_imdb_id(item, media_type, dataset)
    if not imdb_id:
        return None

    if ratings_map is not None:
        imdb_rating = ratings_map.get(imdb_id)
    else:
        imdb_rating = dataset.get_rating(imdb_id, cursor=db_cursor)
    if not imdb_rating:
        return None

    new_rating = imdb_rating["rating"]
    new_votes = imdb_rating["votes"]

    existing_imdb = existing_ratings.get("imdb", {})
    old_rating = existing_imdb.get("rating") if existing_imdb else None

    is_add = old_rating is None
    if not is_add and abs(old_rating - new_rating) <= 0.01:
        return (dbid, None, imdb_id, new_rating, new_votes, title, str(year) if year else "", False)

    kodi_ratings = {
        "imdb": {
            "rating": new_rating,
            "votes": new_votes,
            "default": True
        }
    }
    _preserve_other_ratings(existing_ratings, kodi_ratings)

    return (dbid, kodi_ratings, imdb_id, new_rating, new_votes, title, str(year) if year else "", is_add)


def _update_single_item_imdb(
    item: Dict,
    media_type: str,
    abort_flag=None,
    db_cursor=None
) -> tuple[Optional[bool], Optional[Dict]]:
    """
    Update IMDb ratings for a single item using the dataset.

    Args:
        item: Library item dictionary
        media_type: Type of media
        abort_flag: Optional abort flag to check for cancellation
        db_cursor: Optional database cursor for bulk operations (avoids connection overhead)

    Returns:
        Tuple of (success status, item stats dict)
    """
    dbid = item.get("movieid") or item.get("episodeid") or item.get("tvshowid")
    if not dbid:
        return False, None

    title = item.get("title", "Unknown")
    year = item.get("year")
    uniqueid = item.get("uniqueid", {})
    existing_ratings = item.get("ratings", {})

    season_num: Optional[int] = None
    episode_num: Optional[int] = None
    lookup_uniqueid = uniqueid

    if media_type == "episode":
        season_num = item.get("season")
        episode_num = item.get("episode")
        tvshow_dbid = item.get("tvshowid")
        if tvshow_dbid:
            tvshow_uniqueid = _get_tvshow_uniqueid(tvshow_dbid)
            if tvshow_uniqueid:
                lookup_uniqueid = tvshow_uniqueid

    imdb_id = uniqueid.get("imdb") or None

    if not imdb_id and media_type == "episode":
        show_imdb = lookup_uniqueid.get("imdb")
        if show_imdb and season_num is not None and episode_num is not None:
            dataset = get_imdb_dataset()
            imdb_id = dataset.get_episode_imdb_id(show_imdb, season_num, episode_num)

    if not imdb_id:
        log("Ratings", f"Skipped (no IMDb ID): {title} ({year})", xbmc.LOGDEBUG)
        return None, None

    if abort_flag and abort_flag.is_requested():
        return None, None

    dataset = get_imdb_dataset()
    imdb_rating = dataset.get_rating(imdb_id, cursor=db_cursor)

    if not imdb_rating:
        log("Ratings", f"Skipped (no rating data): {title} ({year}) - {imdb_id}", xbmc.LOGDEBUG)
        return None, None

    new_rating = imdb_rating["rating"]
    new_votes = imdb_rating["votes"]

    existing_imdb = existing_ratings.get("imdb", {})
    old_rating = existing_imdb.get("rating") if existing_imdb else None

    added_ratings = []
    updated_ratings = []

    if old_rating is None:
        added_ratings.append(f"imdb ({new_rating:.1f})")
    elif abs(old_rating - new_rating) > 0.01:
        updated_ratings.append(f"imdb ({old_rating:.1f} -> {new_rating:.1f})")
    else:
        return True, None

    kodi_ratings = {
        "imdb": {
            "rating": new_rating,
            "votes": new_votes,
            "default": True
        }
    }

    _preserve_other_ratings(existing_ratings, kodi_ratings)

    method_info = KODI_SET_DETAILS_METHODS.get(media_type)
    if not method_info:
        return False, None
    method, id_key = method_info

    response = request(method, {id_key: dbid, "ratings": kodi_ratings})

    if response is not None:
        db.update_synced_ratings(
            media_type, dbid,
            {"imdb": {"rating": new_rating, "votes": new_votes}},
            {"imdb": imdb_id}
        )

    item_stats = {
        "title": title,
        "year": year,
        "sources_used": ["imdb_dataset"],
        "ratings_added": len(added_ratings),
        "ratings_updated": len(updated_ratings),
        "added_details": added_ratings,
        "updated_details": updated_ratings,
    }

    return response is not None, item_stats


def _resolve_item_ids(item: Dict, media_type: str) -> Optional[Dict]:
    """Resolve external IDs for a library item.

    Returns:
        Dict of external IDs or None if no usable IDs found
    """
    uniqueid = item.get("uniqueid", {})

    if media_type == "episode":
        tvshow_dbid = item.get("tvshowid")
        if not tvshow_dbid:
            return None
        tvshow_uniqueid = _get_tvshow_uniqueid(tvshow_dbid)
        if not tvshow_uniqueid:
            return None
        show_imdb = tvshow_uniqueid.get("imdb")
        episode_imdb = uniqueid.get("imdb")
        season_num = item.get("season")
        episode_num = item.get("episode")
        if not episode_imdb and show_imdb:
            dataset = get_imdb_dataset()
            episode_imdb = dataset.get_episode_imdb_id(
                show_imdb,
                season_num or 0,
                episode_num or 0,
            )
        if not episode_imdb:
            episode_imdb = get_imdb_id_from_tmdb(
                media_type, tvshow_uniqueid, season_num, episode_num,
            )
        ids = {
            "tmdb": tvshow_uniqueid.get("tmdb"),
            "imdb": show_imdb,
            "imdb_episode": episode_imdb,
            "tvdb": tvshow_uniqueid.get("tvdb"),
            "season": str(item.get("season", "")),
            "episode": str(item.get("episode", "")),
        }
    else:
        raw_tmdb = uniqueid.get("tmdb")
        raw_imdb = uniqueid.get("imdb")
        ids = {
            "tmdb": resolve_tmdb_id(raw_tmdb, raw_imdb, media_type),
            "imdb": raw_imdb,
            "tvdb": uniqueid.get("tvdb"),
        }

    if not ids.get("tmdb") and not ids.get("imdb"):
        return None

    return ids


def _get_imdb_dataset_rating(ids: Dict, media_type: str) -> Tuple[List[Dict], List[str]]:
    """Fetch IMDb dataset rating for an item's IDs.

    Returns:
        Tuple of (initial_ratings list, initial_sources list)
    """
    imdb_id = ids.get("imdb_episode") if media_type == "episode" else ids.get("imdb")
    if imdb_id:
        imdb_dataset = get_imdb_dataset()
        imdb_rating = imdb_dataset.get_rating(imdb_id)
        if imdb_rating:
            return [{"imdb": imdb_rating, "_source": "imdb_dataset"}], ["imdb_dataset"]
    return [], []


def _merge_and_apply_ratings(
    media_type: str,
    dbid: int,
    title: str,
    year: Optional[str],
    all_ratings: List[Dict],
    sources_used: List[str],
    existing_ratings: Dict,
    ids: Dict,
    retryable_failures: Optional[List[dict]] = None,
) -> Tuple[Optional[bool], Optional[Dict]]:
    """Merge fetched ratings, apply to Kodi library, and sync to DB."""
    if retryable_failures is None:
        retryable_failures = []

    if not all_ratings:
        log("Ratings", "No ratings returned from any source", xbmc.LOGDEBUG)
        if retryable_failures:
            return False, {
                "title": title, "year": year,
                "sources_used": [], "ratings_added": 0, "ratings_updated": 0,
                "added_details": [], "updated_details": [],
                "retryable_failures": retryable_failures,
            }
        return False, None

    merged = merge_ratings(all_ratings)

    final_ratings: Dict[str, Dict[str, float]] = {}
    for rating_name, rating_data in existing_ratings.items():
        if isinstance(rating_data, dict) and rating_data.get("rating") is not None:
            final_ratings[rating_name] = {
                "rating": rating_data["rating"],
                "votes": float(rating_data.get("votes", 0)),
            }

    added_ratings: List[str] = []
    updated_ratings: List[str] = []
    for rating_name, rating_data in merged.items():
        new_val = rating_data.get("rating")
        if new_val is None:
            continue
        new_votes = float(rating_data.get("votes", 0))

        if rating_name in final_ratings:
            old_val = final_ratings[rating_name]["rating"]
            old_votes = final_ratings[rating_name]["votes"]

            if new_votes > old_votes:
                final_ratings[rating_name] = {"rating": new_val, "votes": new_votes}
                if abs(old_val - new_val) > 0.01:
                    updated_ratings.append(f"{rating_name} ({old_val:.1f} -> {new_val:.1f})")
        else:
            final_ratings[rating_name] = {"rating": new_val, "votes": new_votes}
            added_ratings.append(f"{rating_name} ({new_val:.1f})")

    kodi_ratings = prepare_kodi_ratings(final_ratings, default_source="imdb")

    if added_ratings:
        log("Ratings", f"Added ratings: {', '.join(added_ratings)}", xbmc.LOGDEBUG)
    if updated_ratings:
        log("Ratings", f"Updated ratings: {', '.join(updated_ratings)}", xbmc.LOGDEBUG)

    if not added_ratings and not updated_ratings:
        db.update_synced_ratings(media_type, dbid, final_ratings, _build_external_ids(ids))
        return True, {
            "title": title, "year": year,
            "sources_used": sources_used, "ratings_added": 0, "ratings_updated": 0,
            "added_details": [], "updated_details": [],
            "retryable_failures": retryable_failures,
        }

    method_info = KODI_SET_DETAILS_METHODS.get(media_type)
    if not method_info:
        return False, None
    method, id_key = method_info

    response = request(method, {id_key: dbid, "ratings": kodi_ratings})

    if response is not None:
        db.update_synced_ratings(media_type, dbid, final_ratings, _build_external_ids(ids))

    item_stats = {
        "title": title, "year": year,
        "sources_used": sources_used,
        "ratings_added": len(added_ratings),
        "ratings_updated": len(updated_ratings),
        "added_details": added_ratings,
        "updated_details": updated_ratings,
        "retryable_failures": retryable_failures,
    }

    return response is not None, item_stats


def _prepare_item_for_batch(
    item: Dict,
    media_type: str
) -> Tuple[Optional[int], Optional[str], Optional[str], Optional[Dict], Optional[Dict], Optional[List[Dict]], Optional[List[str]]]:
    """Prepare an item for batch processing by extracting IDs and fetching IMDb dataset rating."""
    dbid = item.get("movieid") or item.get("episodeid") or item.get("tvshowid")
    if not dbid:
        return None, None, None, None, None, None, None

    title = item.get("title", "Unknown")
    year = item.get("year", "")
    existing_ratings = item.get("ratings", {})

    ids = _resolve_item_ids(item, media_type)
    if ids is None:
        return None, None, None, None, None, None, None

    initial_ratings, initial_sources = _get_imdb_dataset_rating(ids, media_type)

    return dbid, title, str(year) if year else "", ids, existing_ratings, initial_ratings, initial_sources


def _finalize_item_ratings(
    state: ItemState,
    media_type: str
) -> Tuple[Optional[bool], Optional[Dict]]:
    """Finalize ratings for an item by merging and applying to Kodi."""
    return _merge_and_apply_ratings(
        media_type=media_type,
        dbid=state.dbid,
        title=state.title,
        year=state.year,
        all_ratings=state.ratings,
        sources_used=state.sources_used,
        existing_ratings=state.existing_ratings,
        ids=state.ids,
        retryable_failures=state.retryable_failures,
    )


def update_single_item(
    item: Dict,
    media_type: str,
    sources: List,
    abort_flag=None,
    force_refresh: bool = True
) -> tuple[Optional[bool], Optional[Dict]]:
    """
    Update ratings for a single item from API sources.

    Note: This is kept for single-item updates (e.g., from context menu).
    For batch updates, use RatingBatchExecutor instead.
    """
    dbid = item.get("movieid") or item.get("episodeid") or item.get("tvshowid")
    if not dbid:
        return False, None

    title = item.get("title", "Unknown")
    year = item.get("year")
    existing_ratings = item.get("ratings", {})

    ids = _resolve_item_ids(item, media_type)
    if ids is None:
        return None, None

    if abort_flag and abort_flag.is_requested():
        return None, None

    all_ratings, sources_used = _get_imdb_dataset_rating(ids, media_type)
    all_ratings = list(all_ratings)
    sources_used = list(sources_used)

    retryable_failures: list[dict] = []

    MAX_TOTAL_WAIT = 30.0
    start_time = time.time()

    with ThreadPoolExecutor(max_workers=len(sources)) as executor:
        futures = {
            executor.submit(source.fetch_ratings, media_type, ids, abort_flag, force_refresh): source
            for source in sources
        }
        pending = set(futures.keys())

        while pending:
            if abort_flag and abort_flag.is_requested():
                executor.shutdown(wait=False)
                return None, None

            if (time.time() - start_time) > MAX_TOTAL_WAIT:
                for future in pending:
                    source = futures[future]
                    source_name = source.__class__.__name__.replace("Api", "").lower()
                    retryable_failures.append({"source": source_name, "reason": "timeout"})
                    log("Ratings", f"   {source_name}: Timeout after {MAX_TOTAL_WAIT}s", xbmc.LOGDEBUG)
                executor.shutdown(wait=False)
                break

            try:
                done = set()
                for future in as_completed(pending, timeout=1.0):
                    done.add(future)
                    source = futures[future]
                    source_name = source.__class__.__name__.replace("Api", "").lower()

                    try:
                        ratings = future.result()
                        if ratings:
                            all_ratings.append(ratings)
                            sources_used.append(source_name)
                    except RateLimitHit as e:
                        action = usage_tracker.handle_rate_limit_error(e.provider, 0, 1)
                        if action == "cancel_all":
                            if abort_flag:
                                abort_flag.request()
                            executor.shutdown(wait=False)
                            return None, None
                        if action == "cancel_batch":
                            executor.shutdown(wait=False)
                            return None, None
                        if action == "retry":
                            retryable_failures.append({"source": source_name, "reason": "rate limit (user chose wait)"})
                        log("Ratings", f"   {source_name}: Rate limit reached", xbmc.LOGDEBUG)
                    except RetryableError as e:
                        log("Ratings", f"   {source_name}: Retryable error: {e.reason}", xbmc.LOGDEBUG)
                        retryable_failures.append({"source": source_name, "reason": e.reason})
                    except Exception as e:
                        log("Ratings", f"   {source_name}: Failed: {str(e)}", xbmc.LOGDEBUG)

                pending -= done

            except FuturesTimeoutError:
                continue

    return _merge_and_apply_ratings(
        media_type=media_type,
        dbid=dbid,
        title=title,
        year=year,
        all_ratings=all_ratings,
        sources_used=sources_used,
        existing_ratings=existing_ratings,
        ids=ids,
        retryable_failures=retryable_failures,
    )
