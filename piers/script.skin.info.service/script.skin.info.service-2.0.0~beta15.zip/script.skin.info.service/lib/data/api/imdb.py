"""IMDb dataset handler - downloads and caches IMDb's public ratings dataset.

IMDb provides free daily dataset exports at https://datasets.imdbws.com/ for
personal, non-commercial use. This module handles downloading, caching, and
lookups from the title.ratings.tsv dataset.

Data is stored in SQLite for minimal RAM usage on low-end devices.
"""
from __future__ import annotations

import gzip
import xbmc
from datetime import datetime
from typing import Optional

from lib.data.api.client import ApiSession
from lib.kodi.client import log
from lib.data.database._infrastructure import get_db

DATASET_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
EPISODE_DATASET_URL = "https://datasets.imdbws.com/title.episode.tsv.gz"
BATCH_SIZE = 10000


class _ImportAborted(Exception):
    pass


class ApiImdbDataset:
    """Handles IMDb dataset download, caching, and lookup via SQLite."""

    def __init__(self):
        self.session = ApiSession(
            service_name="IMDb Dataset",
            base_url="https://datasets.imdbws.com",
            timeout=(10.0, 120.0),
            max_retries=2,
            backoff_factor=1.0
        )

    def get_rating(self, imdb_id: str, cursor=None) -> Optional[dict[str, float | int]]:
        """
        Look up rating for an IMDb ID.

        Args:
            imdb_id: IMDb ID (e.g., "tt0111161")
            cursor: Optional cursor for bulk operations (avoids connection overhead)

        Returns:
            Dict with rating and votes, or None if not found:
            {"rating": 9.3, "votes": 2800000}
        """
        if cursor:
            cursor.execute(
                "SELECT rating, votes FROM imdb_ratings WHERE imdb_id = ?",
                (imdb_id,)
            )
            row = cursor.fetchone()
            if row:
                return {"rating": row["rating"], "votes": row["votes"]}
            return None

        with get_db() as (_, cur):
            cur.execute(
                "SELECT rating, votes FROM imdb_ratings WHERE imdb_id = ?",
                (imdb_id,)
            )
            row = cur.fetchone()
            if row:
                return {"rating": row["rating"], "votes": row["votes"]}
        return None

    def get_ratings_batch(self, imdb_ids: list[str]) -> dict[str, dict[str, float | int]]:
        """
        Look up ratings for multiple IMDb IDs.

        Args:
            imdb_ids: List of IMDb IDs

        Returns:
            Dict mapping IMDb IDs to rating dicts (missing IDs not included)
        """
        if not imdb_ids:
            return {}

        CHUNK_SIZE = 900
        results = {}
        with get_db() as (_, cursor):
            for start in range(0, len(imdb_ids), CHUNK_SIZE):
                chunk = imdb_ids[start:start + CHUNK_SIZE]
                placeholders = ",".join(["?" for _ in chunk])
                cursor.execute(
                    f"SELECT imdb_id, rating, votes FROM imdb_ratings WHERE imdb_id IN ({placeholders})",
                    chunk
                )
                for row in cursor.fetchall():
                    results[row["imdb_id"]] = {"rating": row["rating"], "votes": row["votes"]}
        return results

    def is_dataset_available(self) -> bool:
        """Check if the dataset has been imported to the database."""
        with get_db() as (_, cursor):
            cursor.execute("SELECT COUNT(*) as cnt FROM imdb_ratings")
            row = cursor.fetchone()
            return row["cnt"] > 0 if row else False

    def refresh_if_stale(self, abort_flag=None) -> bool:
        """
        Check for updates and download if remote is newer.

        Uses HTTP Last-Modified header to detect changes.

        Args:
            abort_flag: Optional abort flag for cancellation

        Returns:
            True if dataset was updated, False if already current or error
        """
        try:
            remote_mod = self._get_remote_last_modified(abort_flag)
            if not remote_mod:
                return False

            local_mod = self._get_local_last_modified()

            if local_mod == remote_mod:
                return False

            log("IMDb", f"Dataset update available (local: {local_mod}, remote: {remote_mod})")
            return self._download_and_import(abort_flag)

        except Exception as e:
            log("IMDb", f"Error checking for dataset updates: {e}", xbmc.LOGWARNING)
            return False

    def force_download(self, abort_flag=None) -> bool:
        """
        Force download the dataset regardless of cache state.

        Args:
            abort_flag: Optional abort flag for cancellation

        Returns:
            True if download succeeded, False otherwise
        """
        return self._download_and_import(abort_flag, force=True)

    def get_stats(self) -> dict[str, int | float | str | bool | None]:
        """
        Get dataset statistics.

        Returns:
            Dict with entry count, last modified date, and downloaded timestamp
        """
        stats: dict[str, int | float | str | bool | None] = {
            "entries": 0,
            "last_modified": None,
            "downloaded_at": None,
        }

        with get_db() as (_, cursor):
            cursor.execute(
                "SELECT last_modified, downloaded_at, entry_count FROM imdb_meta WHERE dataset = ?",
                ("ratings",)
            )
            row = cursor.fetchone()
            if row:
                stats["last_modified"] = row["last_modified"]
                stats["downloaded_at"] = row["downloaded_at"]
                stats["entries"] = row["entry_count"] or 0

        return stats

    def _download_and_import(self, abort_flag=None, force: bool = False) -> bool:
        try:
            log("IMDb", f"Downloading dataset from {DATASET_URL}...")

            headers = None
            if not force:
                local_mod = self._get_local_last_modified()
                headers = {"If-Modified-Since": local_mod} if local_mod else None

            response = self.session.get_raw(
                "/title.ratings.tsv.gz",
                headers=headers,
                abort_flag=abort_flag,
                stream=True
            )

            if response is None:
                return False

            if response.status_code == 304:
                log("IMDb", "Dataset not modified (304), using cached version")
                return False

            last_mod = response.headers.get("Last-Modified")

            count = self._stream_and_import_ratings(response, abort_flag)

            if last_mod:
                self._save_local_last_modified(last_mod, count)

            log("IMDb", f"Imported {count:,} ratings to database")
            return True

        except _ImportAborted:
            return False
        except Exception as e:
            log("IMDb", f"Failed to download dataset: {e}", xbmc.LOGERROR)
            return False

    def _stream_and_import_ratings(self, response, abort_flag=None) -> int:
        count = 0
        batch: list[tuple[str, float, int]] = []

        with get_db() as (_, cursor):
            cursor.execute("DROP TABLE IF EXISTS imdb_ratings")
            cursor.execute('''
                CREATE TABLE imdb_ratings (
                    imdb_id TEXT PRIMARY KEY,
                    rating REAL NOT NULL,
                    votes INTEGER NOT NULL
                )
            ''')
            cursor.execute("PRAGMA synchronous = OFF")

            with gzip.open(response.raw, "rt", encoding="utf-8") as f:
                next(f)
                for line in f:
                    if abort_flag and abort_flag.is_requested():
                        log("IMDb", "Ratings import aborted by user")
                        raise _ImportAborted()

                    parts = line.strip().split("\t")
                    if len(parts) >= 3:
                        try:
                            batch.append((parts[0], float(parts[1]), int(parts[2])))
                            count += 1

                            if len(batch) >= BATCH_SIZE:
                                cursor.executemany(
                                    "INSERT INTO imdb_ratings (imdb_id, rating, votes) VALUES (?, ?, ?)",
                                    batch
                                )
                                batch = []
                        except ValueError:
                            continue

            if batch:
                cursor.executemany(
                    "INSERT INTO imdb_ratings (imdb_id, rating, votes) VALUES (?, ?, ?)",
                    batch
                )

            cursor.execute("PRAGMA synchronous = NORMAL")

        return count

    def _get_remote_last_modified(self, abort_flag=None) -> Optional[str]:
        """Get Last-Modified header from remote server via HEAD request."""
        try:
            response = self.session.head(
                "/title.ratings.tsv.gz",
                abort_flag=abort_flag,
                timeout=(5.0, 10.0)
            )
            if response:
                return response.headers.get("Last-Modified")
            return None
        except Exception as e:
            log("IMDb", f"Failed to check remote Last-Modified: {e}", xbmc.LOGWARNING)
            return None

    def _get_local_last_modified(self) -> Optional[str]:
        """Get stored Last-Modified from previous download."""
        with get_db() as (_, cursor):
            cursor.execute(
                "SELECT last_modified FROM imdb_meta WHERE dataset = ?",
                ("ratings",)
            )
            row = cursor.fetchone()
            if row and row["last_modified"]:
                return row["last_modified"]
        return None

    def _save_local_last_modified(self, last_mod: str, entry_count: int = 0) -> None:
        """Store Last-Modified and entry count in database."""
        with get_db() as (_, cursor):
            cursor.execute(
                """INSERT OR REPLACE INTO imdb_meta
                   (dataset, last_modified, downloaded_at, entry_count)
                   VALUES (?, ?, ?, ?)""",
                ("ratings", last_mod, datetime.now().isoformat(), entry_count)
            )

    def _clear_meta(self, dataset: str) -> None:
        with get_db() as (_, cursor):
            cursor.execute("DELETE FROM imdb_meta WHERE dataset = ?", (dataset,))

    # Episode dataset methods

    def get_episode_imdb_id(
        self, show_imdb_id: str, season: int, episode: int, cursor=None
    ) -> Optional[str]:
        """
        Look up episode IMDb ID by show + season + episode.

        Args:
            show_imdb_id: IMDb ID of the TV show (e.g., "tt0944947")
            season: Season number
            episode: Episode number
            cursor: Optional cursor for bulk operations

        Returns:
            Episode IMDb ID (e.g., "tt4283088") or None if not found
        """
        if cursor:
            cursor.execute(
                "SELECT episode_id FROM imdb_episodes WHERE parent_id = ? AND season = ? AND episode = ?",
                (show_imdb_id, season, episode)
            )
            row = cursor.fetchone()
            return row["episode_id"] if row else None

        with get_db() as (_, cur):
            cur.execute(
                "SELECT episode_id FROM imdb_episodes WHERE parent_id = ? AND season = ? AND episode = ?",
                (show_imdb_id, season, episode)
            )
            row = cur.fetchone()
            return row["episode_id"] if row else None

    def get_episodes_for_show(self, show_imdb_id: str) -> dict[tuple[int, int], str]:
        """
        Get all episode IMDb IDs for a show.

        Args:
            show_imdb_id: IMDb ID of the TV show

        Returns:
            Dict mapping (season, episode) tuples to episode IMDb IDs
        """
        result: dict[tuple[int, int], str] = {}
        with get_db() as (_, cursor):
            cursor.execute(
                "SELECT season, episode, episode_id FROM imdb_episodes WHERE parent_id = ?",
                (show_imdb_id,)
            )
            for row in cursor.fetchall():
                result[(row["season"], row["episode"])] = row["episode_id"]
        return result

    def is_episode_dataset_available(self) -> bool:
        """Check if the episode dataset has been imported."""
        with get_db() as (_, cursor):
            cursor.execute("SELECT COUNT(*) as cnt FROM imdb_episodes")
            row = cursor.fetchone()
            return row["cnt"] > 0 if row else False

    def get_episode_dataset_stats(self) -> dict[str, int | str | None]:
        """Get episode dataset statistics."""
        stats: dict[str, int | str | None] = {
            "entries": 0,
            "last_modified": None,
            "downloaded_at": None,
        }
        with get_db() as (_, cursor):
            cursor.execute(
                "SELECT last_modified, downloaded_at, entry_count FROM imdb_meta WHERE dataset = ?",
                ("episodes",)
            )
            row = cursor.fetchone()
            if row:
                stats["last_modified"] = row["last_modified"]
                stats["downloaded_at"] = row["downloaded_at"]
                stats["entries"] = row["entry_count"] or 0
        return stats

    def refresh_episode_dataset(
        self,
        user_show_ids: set[str],
        library_episode_count: int = 0,
        progress_callback=None,
        abort_flag=None
    ) -> int:
        """
        Download episode dataset and filter to user's shows.

        Args:
            user_show_ids: Set of IMDb IDs for shows in user's library
            library_episode_count: Current total episode count from Kodi (for cache invalidation)
            progress_callback: Optional callback(status_text) for progress updates
            abort_flag: Optional abort flag for cancellation

        Returns:
            Number of episodes imported, or -1 on error
        """
        if not user_show_ids:
            return 0

        try:
            if progress_callback:
                progress_callback("Downloading episode data...")

            log("IMDb", f"Downloading episode dataset from {EPISODE_DATASET_URL}...")

            response = self.session.get_raw(
                "/title.episode.tsv.gz",
                abort_flag=abort_flag,
                stream=True,
                timeout=(10.0, 180.0)
            )

            if response is None:
                return -1

            last_mod = response.headers.get("Last-Modified")

            if progress_callback:
                progress_callback("Processing episodes...")

            count = self._stream_and_filter_episodes(response, user_show_ids, abort_flag)

            if last_mod:
                self._save_episode_meta(last_mod, count, library_episode_count)

            log("IMDb", f"Imported {count:,} episode IDs for {len(user_show_ids)} shows")
            return count

        except _ImportAborted:
            self._clear_meta("episodes")
            return -1
        except Exception as e:
            log("IMDb", f"Failed to download episode dataset: {e}", xbmc.LOGERROR)
            return -1

    def _stream_and_filter_episodes(
        self, response, user_show_ids: set[str], abort_flag=None
    ) -> int:
        """
        Stream gzip response and filter to user's shows.

        Processes the file line-by-line without loading entire dataset into memory.
        """
        count = 0
        batch: list[tuple[str, int, int, str]] = []

        with get_db() as (_, cursor):
            cursor.execute("DROP TABLE IF EXISTS imdb_episodes")
            cursor.execute('''
                CREATE TABLE imdb_episodes (
                    parent_id TEXT NOT NULL,
                    season INTEGER NOT NULL,
                    episode INTEGER NOT NULL,
                    episode_id TEXT NOT NULL,
                    PRIMARY KEY (parent_id, season, episode)
                )
            ''')
            cursor.execute("PRAGMA synchronous = OFF")

            with gzip.open(response.raw, "rt", encoding="utf-8") as f:
                next(f)  # Skip header: tconst, parentTconst, seasonNumber, episodeNumber

                for line in f:
                    if abort_flag and abort_flag.is_requested():
                        log("IMDb", "Episode import aborted by user")
                        raise _ImportAborted()

                    parts = line.strip().split("\t")
                    if len(parts) >= 4:
                        ep_id, parent_id, season_str, episode_str = parts[0], parts[1], parts[2], parts[3]

                        if parent_id in user_show_ids and season_str != "\\N" and episode_str != "\\N":
                            try:
                                season = int(season_str)
                                episode = int(episode_str)
                                batch.append((parent_id, season, episode, ep_id))
                                count += 1

                                if len(batch) >= BATCH_SIZE:
                                    cursor.executemany(
                                        "INSERT OR REPLACE INTO imdb_episodes (parent_id, season, episode, episode_id) VALUES (?, ?, ?, ?)",
                                        batch
                                    )
                                    batch = []
                            except ValueError:
                                continue

            if batch:
                cursor.executemany(
                    "INSERT OR REPLACE INTO imdb_episodes (parent_id, season, episode, episode_id) VALUES (?, ?, ?, ?)",
                    batch
                )

            cursor.execute("CREATE INDEX IF NOT EXISTS idx_imdb_episodes_parent ON imdb_episodes(parent_id)")
            cursor.execute("PRAGMA synchronous = NORMAL")

        return count

    def _get_episode_meta(self) -> tuple[Optional[str], int]:
        """Get stored Last-Modified and library episode count for episode dataset."""
        with get_db() as (_, cursor):
            cursor.execute(
                "SELECT last_modified, library_episode_count FROM imdb_meta WHERE dataset = ?",
                ("episodes",)
            )
            row = cursor.fetchone()
            if row:
                return row["last_modified"], row["library_episode_count"] or 0
            return None, 0

    def needs_episode_refresh(self, library_episode_count: int, abort_flag=None) -> bool:
        """
        Check if episode dataset needs refresh without downloading.

        Args:
            library_episode_count: Current total episode count from Kodi
            abort_flag: Optional abort flag for cancellation

        Returns:
            True if refresh needed, False if current
        """
        try:
            local_mod, stored_ep_count = self._get_episode_meta()

            if stored_ep_count != library_episode_count:
                log("IMDb", f"Library episode count changed ({stored_ep_count} -> {library_episode_count})")
                return True

            response = self.session.head(
                "/title.episode.tsv.gz",
                abort_flag=abort_flag,
                timeout=(5.0, 10.0)
            )

            if response:
                remote_mod = response.headers.get("Last-Modified")
                if not local_mod or local_mod != remote_mod:
                    log("IMDb", "IMDb dataset updated")
                    return True

            return False

        except Exception as e:
            log("IMDb", f"Error checking episode dataset status: {e}", xbmc.LOGWARNING)
            return False

    def _save_episode_meta(self, last_mod: str, entry_count: int, library_episode_count: int) -> None:
        """Store Last-Modified and library episode count for episode dataset."""
        with get_db() as (_, cursor):
            cursor.execute(
                """INSERT OR REPLACE INTO imdb_meta
                   (dataset, last_modified, downloaded_at, entry_count, library_episode_count)
                   VALUES (?, ?, ?, ?, ?)""",
                ("episodes", last_mod, datetime.now().isoformat(), entry_count, library_episode_count)
            )


_imdb_dataset: ApiImdbDataset | None = None


def get_imdb_dataset() -> ApiImdbDataset:
    """Get the singleton IMDb dataset instance."""
    global _imdb_dataset
    if _imdb_dataset is None:
        _imdb_dataset = ApiImdbDataset()
    return _imdb_dataset
