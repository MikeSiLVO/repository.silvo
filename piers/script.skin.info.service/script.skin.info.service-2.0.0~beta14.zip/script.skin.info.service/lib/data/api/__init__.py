"""API clients for external services (TMDB, Fanart.tv, ratings providers)."""
