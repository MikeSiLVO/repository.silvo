"""Run the background service, capturing user data as Kodi announces it."""

import os
import sqlite3
import time
from queue import Empty, Queue
from typing import Callable

import xbmc

from lib.data.database import (DatabaseBusy, close_database, count_rebuilt, get_db, holdings,
                               mark_rebuilt, new_connection, next_batch, open_database,
                               snapshot, stamp_now)
from lib.kodi.client import ADDON, Listener, log
from lib.kodi.dialogs import BackgroundProgress, addon_name, text
from lib.kodi.slot import SlotTaken, claim, holder, stopping
from lib.kodi.utilities import database_path, wait_for_kodi_ready
from lib.sync.backup import (backup_item, library_settled, announced_item,
                             removed_item, sweep)
from lib.sync.folder import keep_in_step, note_change
from lib.sync.restore import restore_library

DRAIN_INTERVAL = 1.0
BACKLOG_INTERVAL = 0.1
DRAIN_BATCH = 50
SWEEP_INTERVAL = 6 * 60 * 60
FILL_WAIT = 2 * 60
PLAYBACK_REST = 3 * 60
BROWSING = "Window.IsActive(videos)"
PLAYING = "Player.HasVideo"
FILLING = "the automatic fill"

_pending = {}
_settled = False
_waiting = 0.0
_rebuilding = False
_next_sweep = 0.0
_played_at = float("-inf")
_looked_at = float("-inf")


def main() -> None:
    """Open the database and capture announcements until Kodi asks the service to stop."""
    global _settled, _next_sweep
    path = database_path()
    open_database(path)
    held = holdings()
    log("opened {0}".format(path))
    log("holding {0} movies, {1} shows, {2} episodes, {3} with watch history".format(
        held.get("movie", 0), held.get("tvshow", 0), held.get("episode", 0), held["watched"]))
    queue = Queue()
    listener = Listener(queue)
    try:
        if not wait_for_kodi_ready(listener):
            return
        _settled = any(count for kind, count in held.items() if kind != "watched")
        _next_sweep = _last_swept() + SWEEP_INTERVAL
        log("watching for changes")
        while not listener.abortRequested():
            if listener.waitForAbort(BACKLOG_INTERVAL if _pending else DRAIN_INTERVAL):
                break
            try:
                drain(queue)
                if fill_due():
                    run_fill()
                if sweep_due():
                    run_sweep(lambda: listener.abortRequested() or watching())
                if not _pending and not xbmc.getCondVisibility(PLAYING):
                    keep_in_step(lambda: listener.abortRequested() or watching())
            except Exception:
                import traceback
                log("drain failed\n" + traceback.format_exc(), xbmc.LOGERROR)
    finally:
        close_database()
        log("stopped")


def drain(queue: Queue) -> None:
    """Drain the queue: mark removals, note a settled library or an ended video, capture a batch."""
    global _rebuilding, _settled, _played_at
    removals = []
    while True:
        try:
            method, data = queue.get_nowait()
        except Empty:
            break
        item = announced_item(method, data)
        if item is not None:
            _pending[item] = None
        gone = removed_item(method, data)
        if gone is not None:
            removals.append(gone)
        if library_settled(method):
            _settled = True
        if method == "Player.OnStop":
            _played_at = time.monotonic()
    if not _pending and not removals:
        return
    shows = {}
    try:
        with get_db() as cursor:
            if removals:
                when = stamp_now()
                for kind, dbid in removals:
                    mark_rebuilt(cursor, kind, dbid, when)
                _rebuilding = True
                log("{0} items left the library, holding their data".format(len(removals)))
            for _ in range(min(len(_pending), DRAIN_BATCH)):
                kind, dbid = next(iter(_pending))
                try:
                    backup_item(cursor, kind, dbid, shows=shows)
                    cursor.connection.commit()
                    note_change()
                except sqlite3.OperationalError:
                    cursor.connection.rollback()
                    log("database locked, {0} items held for the next pass".format(len(_pending)))
                    return
                except Exception:
                    import traceback
                    log("could not capture {0} dbid {1}\n{2}".format(
                        kind, dbid, traceback.format_exc()), xbmc.LOGERROR)
                del _pending[(kind, dbid)]
    except DatabaseBusy:
        log("database busy, {0} items held for the next pass".format(len(_pending)))


def fill_due() -> bool:
    """True once the library settled, no video played lately, nobody writes; browsing defers it."""
    global _waiting
    if not _settled or xbmc.getCondVisibility("Library.IsScanningVideo"):
        return False
    if watching():
        _waiting = 0.0
        return False
    if holder():
        return False
    if not xbmc.getCondVisibility(BROWSING):
        _waiting = 0.0
        return True
    if _rebuilding:
        return True
    if not _waiting:
        _waiting = time.time()
        log("holding the fill back, a video window is open")
        return False
    if time.time() - _waiting < FILL_WAIT:
        return False
    _waiting = 0.0
    return True


def watching() -> bool:
    """True while a video is open and for a rest after it closes, checked once a second at most."""
    global _played_at, _looked_at
    now = time.monotonic()
    if now - _looked_at >= 1.0:
        _looked_at = now
        if xbmc.getCondVisibility(PLAYING):
            _played_at = now
    return now - _played_at < PLAYBACK_REST


def run_fill() -> None:
    """Fill in what the library is missing, unless another run is writing."""
    global _rebuilding, _settled
    try:
        with claim(FILLING):
            rebuilding = _rebuilding
            _settled = False
            _rebuilding = False
            _fill()
            if stopping() or watching():
                _settled = True
                _rebuilding = rebuilding
    except SlotTaken as taken:
        log("not filling, {0} is writing".format(taken))
    except sqlite3.OperationalError:
        _settled = True
        log("database locked, filling later")


def _fill() -> None:
    """Walk the library once on its own connection, never overwriting what Kodi holds."""
    bar = BackgroundProgress(addon_name(), text(32007))

    def step(index: int, total: int, title: str) -> bool:
        if watching():
            log("giving up, a video started")
            return False
        return bar.step(index, total, title)

    connection = new_connection()
    try:
        cursor = connection.cursor()
        marked = count_rebuilt(cursor)
        counts = restore_library(cursor, step, batch=next_batch(cursor), filling=True,
                                 on_restore=bar.start)
        connection.commit()
        log("filled {0} of {1} items checked, {2} were waiting after a rebuild".format(
            counts["restored"], counts["checked"], marked))
    finally:
        bar.close()
        connection.close()


def sweep_due() -> bool:
    """True when a sweep is overdue and no video has played lately."""
    return time.time() >= _next_sweep and not watching()


def run_sweep(should_stop: Callable[[], bool]) -> None:
    """Sweep the library on its own connection and snapshot; a rebuild it saw lets a fill run."""
    global _next_sweep, _settled
    _next_sweep = time.time() + SWEEP_INTERVAL
    connection = new_connection()
    try:
        cursor = connection.cursor()
        counts = sweep(cursor, should_stop=should_stop)
        connection.commit()
    finally:
        connection.close()
    if counts["moved"]:
        # a rebuild on another client sharing the library announces nothing here
        _settled = True
    if should_stop():
        log("sweep cut short, trying again later")
        _next_sweep = time.time()
        return
    ADDON.setSetting("last_swept", str(int(time.time())))
    note_change()
    taken = snapshot()
    log("swept {0} movies, {1} shows, {2} episodes, {3} with a new library id; "
        "snapshot {4}".format(counts.get("movie", 0), counts.get("tvshow", 0),
                              counts.get("episode", 0), counts["moved"],
                              os.path.basename(taken) or "none needed"))


def _last_swept() -> float:
    """When the last sweep finished, as a Unix time, or zero when none has."""
    try:
        return float(ADDON.getSetting("last_swept") or 0)
    except ValueError:
        return 0.0
