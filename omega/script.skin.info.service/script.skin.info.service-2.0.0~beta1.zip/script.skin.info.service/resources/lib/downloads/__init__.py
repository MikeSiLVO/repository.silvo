"""Artwork filesystem download functionality."""
