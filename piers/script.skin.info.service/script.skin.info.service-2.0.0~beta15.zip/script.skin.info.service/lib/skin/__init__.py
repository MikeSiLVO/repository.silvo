"""Skin utility functions for script.skin.info.service."""
